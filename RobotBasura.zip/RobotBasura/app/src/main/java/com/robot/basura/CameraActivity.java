package com.robot.basura;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;
import java.util.List;

public class CameraActivity extends Activity implements TextureView.SurfaceTextureListener {
    Camera cam;
    TextureView tv;
    SurfaceTexture st;
    Button fl;
    boolean flash = true; // por defecto el flash se enciende al entrar

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        tv = new TextureView(this);
        tv.setSurfaceTextureListener(this);
        root.addView(tv, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        fl = new Button(this);
        fl.setText("Flash: ON");
        fl.setOnClickListener(v -> { flash = !flash; applyFlash(); });
        Button back = new Button(this);
        back.setText("Volver");
        back.setOnClickListener(v -> finish());
        bar.addView(fl);
        bar.addView(back);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.RIGHT);
        lp.setMargins(0, 0, 24, 24);
        root.addView(bar, lp);
        setContentView(root);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 1);
    }

    @Override
    public void onRequestPermissionsResult(int c, String[] p, int[] r) {
        if (r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED) openCam();
        else { Toast.makeText(this, "Se necesita permiso de cámara", Toast.LENGTH_LONG).show(); finish(); }
    }

    void openCam() {
        if (cam != null || st == null || checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        try {
            cam = Camera.open(); // cámara trasera
            Camera.Parameters p = cam.getParameters();
            Camera.Size best = null;
            for (Camera.Size s : p.getSupportedPreviewSizes()) {
                if (Math.abs((float) s.width / s.height - 16f / 9f) < 0.05f && s.width <= 1280
                        && (best == null || s.width > best.width)) best = s;
            }
            if (best != null) p.setPreviewSize(best.width, best.height);
            List<String> fm = p.getSupportedFocusModes();
            if (fm != null && fm.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO))
                p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
            cam.setParameters(p);
            Camera.CameraInfo info = new Camera.CameraInfo();
            Camera.getCameraInfo(0, info);
            int deg = getWindowManager().getDefaultDisplay().getRotation() * 90;
            cam.setDisplayOrientation((info.orientation - deg + 360) % 360);
            cam.setPreviewTexture(st);
            cam.startPreview();
            applyFlash();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir la cámara", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    void applyFlash() {
        fl.setText(flash ? "Flash: ON" : "Flash: OFF");
        if (cam == null) return;
        try {
            Camera.Parameters p = cam.getParameters();
            List<String> m = p.getSupportedFlashModes();
            if (m == null || !m.contains(Camera.Parameters.FLASH_MODE_TORCH)) {
                Toast.makeText(this, "Este teléfono no tiene flash", Toast.LENGTH_SHORT).show();
                return;
            }
            p.setFlashMode(flash ? Camera.Parameters.FLASH_MODE_TORCH : Camera.Parameters.FLASH_MODE_OFF);
            cam.setParameters(p);
        } catch (Exception ignored) {}
    }

    void closeCam() {
        if (cam != null) { try { cam.stopPreview(); } catch (Exception ignored) {} cam.release(); cam = null; }
    }

    @Override protected void onResume() { super.onResume(); openCam(); }
    @Override protected void onPause() { super.onPause(); closeCam(); }
    @Override public void onSurfaceTextureAvailable(SurfaceTexture s, int w, int h) { st = s; openCam(); }
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture s) { closeCam(); st = null; return true; }
    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture s, int w, int h) {}
    @Override public void onSurfaceTextureUpdated(SurfaceTexture s) {}
}
