# Robot Basura (Android 6+, Samsung J7 SM-J700M)
Cara animada para tu robot: ojos en pantalla negra, controlados solo con acelerómetro y sensor de proximidad.

## Cómo obtener el APK
1. Sube esta carpeta a un repositorio de GitHub.
2. Pestaña **Actions** → workflow **Build APK** (corre solo al hacer push, o "Run workflow").
3. Cuando termine, descarga el artefacto **RobotBasura-apk** (un .zip con `app-debug.apk`).
4. Pásalo al teléfono, permite "instalar apps de orígenes desconocidos" e instálalo.

También puedes abrir la carpeta con Android Studio y darle Run.

## Uso
- Engranaje (arriba derecha, casi invisible): color, skins, espera entre expresiones, sensibilidad, expresión por situación, probar expresiones y "Ver capacidad del depósito" (cámara trasera con flash encendido).
- Candado (abajo izquierda, casi invisible): toca para bloquear; para desbloquear mantenlo presionado ~1.2 s.
- Acariciar: toca o desliza el dedo sobre la pantalla.
- El código de las caras está en `app/src/main/assets/index.html`.
